package appointmentservice;

/*
 * Name: Carla Nemley
 * Course: CS 320 – Software Testing Automation
 * Instructor: Kalysa Wilson
 * Date: June 7, 2026
 * Description: This class manages Appointment objects in memory and
 * provides services for adding and deleting appointments.
 */

import java.util.HashMap;

public class AppointmentService {

    // I chose a HashMap because it allows fast lookup by appointment ID.
    private final HashMap<String, Appointment> appointments = new HashMap<>();

    public void addAppointment(Appointment appointment) {

        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null");
        }

        if (appointments.containsKey(appointment.getAppointmentID())) {
            throw new IllegalArgumentException("Duplicate appointment ID");
        }

        appointments.put(appointment.getAppointmentID(), appointment);
    }

    public void deleteAppointment(String appointmentID) {
        appointments.remove(appointmentID);
    }

    public Appointment getAppointment(String appointmentID) {
        return appointments.get(appointmentID);
    }
}