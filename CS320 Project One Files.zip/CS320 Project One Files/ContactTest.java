/*
 * Name: Carla Nemley
 * Course: CS 320 – Software Testing Automation
 * Instructor: Kalysa Wilson
 * Date: May 24, 2026
 * Description: This file contains JUnit 5 tests for the Contact class.
 * I created these tests to verify all validation rules and object
 * behavior required by the project.
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void testValidContactCreation() {

        Contact contact = new Contact(
                "12345",
                "Carla",
                "Nemley",
                "1234567890",
                "123 Main St");

        assertEquals("12345", contact.getContactID());
        assertEquals("Carla", contact.getFirstName());
        assertEquals("Nemley", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    @Test
    public void testNullContactIDRejected() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact(null, "Carla", "Nemley",
                    "1234567890", "123 Main St");
        });
    }

    @Test
    public void testLongContactIDRejected() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345678901", "Carla", "Nemley",
                    "1234567890", "123 Main St");
        });
    }

    @Test
    public void testNullFirstNameRejected() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", null, "Nemley",
                    "1234567890", "123 Main St");
        });
    }

    @Test
    public void testLongFirstNameRejected() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "VeryLongName",
                    "Nemley", "1234567890", "123 Main St");
        });
    }

    @Test
    public void testNullLastNameRejected() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Carla", null,
                    "1234567890", "123 Main St");
        });
    }

    @Test
    public void testLongLastNameRejected() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Carla",
                    "VeryLongLastName", "1234567890",
                    "123 Main St");
        });
    }

    @Test
    public void testInvalidPhoneRejected() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Carla", "Nemley",
                    "12345", "123 Main St");
        });
    }

    @Test
    public void testPhoneMustContainOnlyDigits() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Carla", "Nemley",
                    "abcdefghij", "123 Main St");
        });
    }

    @Test
    public void testLongAddressRejected() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Contact("12345", "Carla", "Nemley",
                    "1234567890",
                    "1234567890123456789012345678901");
        });
    }

    @Test
    public void testUpdateFirstName() {

        Contact contact = new Contact(
                "12345", "Carla", "Nemley",
                "1234567890", "123 Main St");

        contact.setFirstName("Updated");

        assertEquals("Updated", contact.getFirstName());
    }

    @Test
    public void testUpdateLastName() {

        Contact contact = new Contact(
                "12345", "Carla", "Nemley",
                "1234567890", "123 Main St");

        contact.setLastName("Wilson");

        assertEquals("Wilson", contact.getLastName());
    }

    @Test
    public void testUpdatePhone() {

        Contact contact = new Contact(
                "12345", "Carla", "Nemley",
                "1234567890", "123 Main St");

        contact.setPhone("0987654321");

        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    public void testUpdateAddress() {

        Contact contact = new Contact(
                "12345", "Carla", "Nemley",
                "1234567890", "123 Main St");

        contact.setAddress("456 Oak Avenue");

        assertEquals("456 Oak Avenue", contact.getAddress());
    }

    @Test
    public void testContactIDCannotBeUpdated() {

        Contact contact = new Contact(
                "12345", "Carla", "Nemley",
                "1234567890", "123 Main St");

        // Since there is no setter for contactID,
        // the ID cannot be updated.
        assertEquals("12345", contact.getContactID());
    }
}