/*
 * Name: Carla Nemley
 * Course: CS 320 – Software Testing Automation
 * Instructor: Kalysa Wilson
 * Date: May 24, 2026
 * Description: This class manages Contact objects in memory for the
 * mobile application. I designed this service to support adding,
 * deleting, and updating contacts while enforcing unique IDs.
 */

import java.util.HashMap;

public class ContactService {

    // I chose a HashMap because it allows fast searching
    // by contact ID.
    private final HashMap<String, Contact> contacts = new HashMap<>();

    // Add contact
    public void addContact(Contact contact) {

        // I validate the contact object before storing it.
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null");
        }

        // I enforce unique IDs to satisfy the project requirements.
        if (contacts.containsKey(contact.getContactID())) {
            throw new IllegalArgumentException("Duplicate contact ID");
        }

        contacts.put(contact.getContactID(), contact);
    }

    // Delete contact by ID
    public void deleteContact(String contactID) {

        if (!contacts.containsKey(contactID)) {
            throw new IllegalArgumentException("Contact not found");
        }

        contacts.remove(contactID);
    }

    // Update first name
    public void updateFirstName(String contactID, String firstName) {

        Contact contact = getContact(contactID);
        contact.setFirstName(firstName);
    }

    // Update last name
    public void updateLastName(String contactID, String lastName) {

        Contact contact = getContact(contactID);
        contact.setLastName(lastName);
    }

    // Update phone number
    public void updatePhone(String contactID, String phone) {

        Contact contact = getContact(contactID);
        contact.setPhone(phone);
    }

    // Update address
    public void updateAddress(String contactID, String address) {

        Contact contact = getContact(contactID);
        contact.setAddress(address);
    }

    // Helper method
    private Contact getContact(String contactID) {

        Contact contact = contacts.get(contactID);

        // I use this helper method to avoid repeating
        // the same lookup validation in every update method.
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found");
        }

        return contact;
    }
}