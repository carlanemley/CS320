package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    void testValidTaskCreation() {
        Task task = new Task("12345", "Test Name", "Test Description");

        assertEquals("12345", task.getTaskID());
        assertEquals("Test Name", task.getName());
        assertEquals("Test Description", task.getDescription());
    }

    @Test
    void testInvalidTaskID() {

        assertThrows(IllegalArgumentException.class, () ->
                new Task(null, "Name", "Description"));

        assertThrows(IllegalArgumentException.class, () ->
                new Task("12345678901", "Name", "Description"));
    }

    @Test
    void testInvalidName() {

        assertThrows(IllegalArgumentException.class, () ->
                new Task("123", null, "Description"));

        assertThrows(IllegalArgumentException.class, () ->
                new Task("123", "ThisNameIsWayTooLongForValidation", "Description"));
    }

    @Test
    void testInvalidDescription() {

        assertThrows(IllegalArgumentException.class, () ->
                new Task("123", "Name", null));

        assertThrows(IllegalArgumentException.class, () ->
                new Task("123", "Name",
                        "This description exceeds the maximum allowed fifty character limit for tasks"));
    }

    @Test
    void testSetName() {
        Task task = new Task("123", "Old Name", "Description");
        task.setName("New Name");
        assertEquals("New Name", task.getName());
    }

    @Test
    void testSetDescription() {
        Task task = new Task("123", "Name", "Old Description");
        task.setDescription("New Description");
        assertEquals("New Description", task.getDescription());
    }
}