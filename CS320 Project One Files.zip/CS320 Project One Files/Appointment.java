package appointmentservice;

/*
 * Name: Carla Nemley
 * Course: CS 320 – Software Testing Automation
 * Instructor: Kalysa Wilson
 * Date: June 7, 2026
 * Description: This class defines an Appointment object and enforces
 * all validation requirements provided by the customer.
 */

import java.util.Date;

public class Appointment {

    private final String appointmentID;
    private final Date appointmentDate;
    private final String description;

    public Appointment(String appointmentID, Date appointmentDate, String description) {

        // I validate the appointment ID here to ensure it meets all requirements.
        if (appointmentID == null || appointmentID.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID");
        }

        // I validate the date to ensure appointments cannot be scheduled in the past.
        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Invalid appointment date");
        }

        // I validate the description so that it cannot exceed the required length.
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description");
        }

        this.appointmentID = appointmentID;

        // I create a copy of the Date object to protect the appointment data.
        this.appointmentDate = new Date(appointmentDate.getTime());

        this.description = description;
    }

    public String getAppointmentID() {
        return appointmentID;
    }

    public Date getAppointmentDate() {
        return new Date(appointmentDate.getTime());
    }

    public String getDescription() {
        return description;
    }
}