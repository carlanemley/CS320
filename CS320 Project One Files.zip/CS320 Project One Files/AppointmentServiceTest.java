package appointmentservice;

/*
 * Name: Carla Nemley
 * Course: CS 320 – Software Testing Automation
 * Instructor: Kalysa Wilson
 * Date: June 7, 2026
 * Description: This file contains JUnit tests for the AppointmentService
 * class. I created these tests to verify that appointments can be added
 * and deleted correctly while enforcing unique appointment IDs.
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentServiceTest {

    @Test
    void testAddAppointment() {

        AppointmentService service = new AppointmentService();

        Date future = new Date(System.currentTimeMillis() + 10000);

        Appointment appointment =
            new Appointment("1", future, "Medical Checkup");

        service.addAppointment(appointment);

        assertEquals(appointment, service.getAppointment("1"));
    }

    @Test
    void testAddDuplicateAppointmentID() {

        AppointmentService service = new AppointmentService();

        Date future = new Date(System.currentTimeMillis() + 10000);

        Appointment appointment1 =
            new Appointment("1", future, "Medical Checkup");

        Appointment appointment2 =
            new Appointment("1", future, "Dental Appointment");

        service.addAppointment(appointment1);

        // I verify that duplicate IDs are not allowed.
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(appointment2);
        });
    }

    @Test
    void testAddNullAppointment() {

        AppointmentService service = new AppointmentService();

        // I verify that null appointments cannot be added.
        assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
    }

    @Test
    void testDeleteAppointment() {

        AppointmentService service = new AppointmentService();

        Date future = new Date(System.currentTimeMillis() + 10000);

        Appointment appointment =
            new Appointment("1", future, "Medical Checkup");

        service.addAppointment(appointment);

        service.deleteAppointment("1");

        assertNull(service.getAppointment("1"));
    }

    @Test
    void testDeleteNonexistentAppointment() {

        AppointmentService service = new AppointmentService();

        // I verify that deleting a non-existent appointment does not cause errors.
        service.deleteAppointment("999");

        assertNull(service.getAppointment("999"));
    }
}