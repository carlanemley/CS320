package appointmentservice;

/*
 * Name: Carla Nemley
 * Course: CS 320 – Software Testing Automation
 * Instructor: Kalysa Wilson
 * Date: June 7, 2026
 * Description: This file contains JUnit tests for the Appointment class.
 * I created these tests to verify that all appointment validation rules
 * are enforced correctly.
 */

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentTest {

    @Test
    void testValidAppointmentCreation() {

        Date future = new Date(System.currentTimeMillis() + 10000);

        Appointment appt =
            new Appointment("123", future, "Checkup");

        assertEquals("123", appt.getAppointmentID());
        assertEquals("Checkup", appt.getDescription());
        assertEquals(future, appt.getAppointmentDate());
    }

    @Test
    void testNullAppointmentID() {

        Date future = new Date(System.currentTimeMillis() + 10000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, future, "Description");
        });
    }

    @Test
    void testAppointmentIDTooLong() {

        Date future = new Date(System.currentTimeMillis() + 10000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", future, "Description");
        });
    }

    @Test
    void testMaximumLengthAppointmentID() {

        Date future = new Date(System.currentTimeMillis() + 10000);

        Appointment appt =
            new Appointment("1234567890", future, "Valid Description");

        assertEquals("1234567890", appt.getAppointmentID());
    }

    @Test
    void testNullDate() {

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", null, "Description");
        });
    }

    @Test
    void testPastDate() {

        Date past = new Date(System.currentTimeMillis() - 10000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", past, "Description");
        });
    }

    @Test
    void testNullDescription() {

        Date future = new Date(System.currentTimeMillis() + 10000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", future, null);
        });
    }

    @Test
    void testDescriptionTooLong() {

        Date future = new Date(System.currentTimeMillis() + 10000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                "123",
                future,
                "This description is definitely more than fifty characters long and should fail."
            );
        });
    }

    @Test
    void testDescriptionLengthExactlyFiftyCharacters() {

        Date future = new Date(System.currentTimeMillis() + 10000);

        String description =
            "12345678901234567890123456789012345678901234567890";

        Appointment appt =
            new Appointment("123", future, description);

        assertEquals(description, appt.getDescription());
    }
}
