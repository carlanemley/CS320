package taskservice;

import java.util.HashMap;

/*
 * Name: Carla Nemley
 * Course: CS 320 – Software Testing Automation
 * Instructor: Kalysa Wilson
 * Date: May 30, 2026
 * Description: This service manages Task objects in memory and provides
 * functionality to add, delete, and update tasks by ID.
 */

public class TaskService {

    private HashMap<String, Task> tasks = new HashMap<>();

    public void addTask(Task task) {

        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null");
        }

        if (tasks.containsKey(task.getTaskID())) {
            throw new IllegalArgumentException("Duplicate task ID");
        }

        tasks.put(task.getTaskID(), task);
    }

    public void deleteTask(String taskID) {

        if (!tasks.containsKey(taskID)) {
            throw new IllegalArgumentException("Task not found");
        }

        tasks.remove(taskID);
    }

    public void updateName(String taskID, String newName) {

        Task task = getTask(taskID);
        task.setName(newName);
    }

    public void updateDescription(String taskID, String newDescription) {

        Task task = getTask(taskID);
        task.setDescription(newDescription);
    }

    public Task getTask(String taskID) {

        Task task = tasks.get(taskID);

        if (task == null) {
            throw new IllegalArgumentException("Task not found");
        }

        return task;
    }
}