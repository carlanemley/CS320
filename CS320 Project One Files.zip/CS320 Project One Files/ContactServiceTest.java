/*
 * Name: Carla Nemley
 * Course: CS 320 – Software Testing Automation
 * Instructor: Kalysa Wilson
 * Date: May 24, 2026
 * Description: This file contains JUnit 5 tests for the ContactService
 * class. I created these tests to verify the service correctly stores,
 * deletes, and updates Contact objects in memory.
 */

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    @Test
    public void testAddContact() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "1",
                "Carla",
                "Nemley",
                "1234567890",
                "123 Main St");

        service.addContact(contact);

        // I verify duplicate IDs are rejected.
        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact);
        });
    }

    @Test
    public void testDuplicateContactIDRejected() {

        ContactService service = new ContactService();

        Contact contact1 = new Contact(
                "1", "Carla", "Nemley",
                "1234567890", "123 Main St");

        Contact contact2 = new Contact(
                "1", "John", "Smith",
                "0987654321", "456 Oak Ave");

        service.addContact(contact1);

        assertThrows(IllegalArgumentException.class, () -> {
            service.addContact(contact2);
        });
    }

    @Test
    public void testDeleteContact() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "1", "Carla", "Nemley",
                "1234567890", "123 Main St");

        service.addContact(contact);
        service.deleteContact("1");

        // I verify the contact was removed successfully.
        assertThrows(IllegalArgumentException.class, () -> {
            service.deleteContact("1");
        });
    }

    @Test
    public void testUpdateFirstName() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "1", "Carla", "Nemley",
                "1234567890", "123 Main St");

        service.addContact(contact);

        service.updateFirstName("1", "Updated");

        assertEquals("Updated", contact.getFirstName());
    }

    @Test
    public void testUpdateLastName() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "1", "Carla", "Nemley",
                "1234567890", "123 Main St");

        service.addContact(contact);

        service.updateLastName("1", "Wilson");

        assertEquals("Wilson", contact.getLastName());
    }

    @Test
    public void testUpdatePhone() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "1", "Carla", "Nemley",
                "1234567890", "123 Main St");

        service.addContact(contact);

        service.updatePhone("1", "0987654321");

        assertEquals("0987654321", contact.getPhone());
    }

    @Test
    public void testUpdateAddress() {

        ContactService service = new ContactService();

        Contact contact = new Contact(
                "1", "Carla", "Nemley",
                "1234567890", "123 Main St");

        service.addContact(contact);

        service.updateAddress("1", "456 Oak Avenue");

        assertEquals("456 Oak Avenue", contact.getAddress());
    }

    @Test
    public void testUpdateNonexistentContactFails() {

        ContactService service = new ContactService();

        assertThrows(IllegalArgumentException.class, () -> {
            service.updateFirstName("999", "Test");
        });
    }
}