/*
 * Name: Carla Nemley
 * Course: CS 320 – Software Testing Automation
 * Instructor: Kalysa Wilson
 * Date: May 24, 2026
 * Description: This class represents a Contact object for the mobile
 * application. I designed this class to enforce all validation rules
 * so invalid contact data cannot be created or stored.
 */

public class Contact {

    // I made contactID final because the project requirements state
    // that the ID cannot be updated after creation.
    private final String contactID;

    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    // Constructor
    public Contact(String contactID, String firstName,
                   String lastName, String phone, String address) {

        // I validate all fields during object creation to ensure
        // invalid contacts can never exist in the application.
        validateContactID(contactID);
        validateFirstName(firstName);
        validateLastName(lastName);
        validatePhone(phone);
        validateAddress(address);

        this.contactID = contactID;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;
    }

    // Getters
    public String getContactID() {
        return contactID;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getAddress() {
        return address;
    }

    // Setters for updatable fields only

    public void setFirstName(String firstName) {

        // I validate the first name here so invalid updates
        // cannot be made after object creation.
        validateFirstName(firstName);
        this.firstName = firstName;
    }

    public void setLastName(String lastName) {

        // I validate the last name before updating the field.
        validateLastName(lastName);
        this.lastName = lastName;
    }

    public void setPhone(String phone) {

        // I validate the phone number here to ensure it always
        // contains exactly 10 digits.
        validatePhone(phone);
        this.phone = phone;
    }

    public void setAddress(String address) {

        // I validate the address before saving the update.
        validateAddress(address);
        this.address = address;
    }

    // Validation methods

    private void validateContactID(String contactID) {

        if (contactID == null || contactID.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID");
        }
    }

    private void validateFirstName(String firstName) {

        if (firstName == null || firstName.length() > 10) {
            throw new IllegalArgumentException("Invalid first name");
        }
    }

    private void validateLastName(String lastName) {

        if (lastName == null || lastName.length() > 10) {
            throw new IllegalArgumentException("Invalid last name");
        }
    }

    private void validatePhone(String phone) {

        // I use a regular expression to verify the phone number
        // contains exactly 10 numeric digits.
        if (phone == null || !phone.matches("\\d{10}")) {
            throw new IllegalArgumentException("Invalid phone number");
        }
    }

    private void validateAddress(String address) {

        if (address == null || address.length() > 30) {
            throw new IllegalArgumentException("Invalid address");
        }
    }
}