package taskservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    @Test
    void testAddTask() {
        TaskService service = new TaskService();
        Task task = new Task("1", "Name", "Description");

        service.addTask(task);

        assertEquals(task, service.getTask("1"));
    }

    @Test
    void testAddNullTask() {
        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () ->
                service.addTask(null));
    }

    @Test
    void testAddDuplicateID() {

        TaskService service = new TaskService();

        Task task1 = new Task("1", "Name", "Description");
        Task task2 = new Task("1", "Another", "Another");

        service.addTask(task1);

        assertThrows(IllegalArgumentException.class, () ->
                service.addTask(task2));
    }

    @Test
    void testDeleteTask() {

        TaskService service = new TaskService();
        Task task = new Task("1", "Name", "Description");

        service.addTask(task);
        service.deleteTask("1");

        assertThrows(IllegalArgumentException.class, () ->
                service.getTask("1"));
    }

    @Test
    void testDeleteNonexistentTask() {

        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () ->
                service.deleteTask("999"));
    }

    @Test
    void testUpdateName() {

        TaskService service = new TaskService();
        Task task = new Task("1", "Old Name", "Description");

        service.addTask(task);
        service.updateName("1", "New Name");

        assertEquals("New Name", service.getTask("1").getName());
    }

    @Test
    void testUpdateDescription() {

        TaskService service = new TaskService();
        Task task = new Task("1", "Name", "Old Description");

        service.addTask(task);
        service.updateDescription("1", "New Description");

        assertEquals("New Description", service.getTask("1").getDescription());
    }

    @Test
    void testUpdateNonexistentTask() {

        TaskService service = new TaskService();

        assertThrows(IllegalArgumentException.class, () ->
                service.updateName("999", "New Name"));
    }
}